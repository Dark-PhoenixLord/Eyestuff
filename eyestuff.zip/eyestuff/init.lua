print("This block is watching you")
minetest.register_node("eyestuff:eyeblock", {
    description = "Eyeblock",
    tiles = {
        "eyestuff-eyeblock.png",
        "eyestuff-eyeblock.png",
        "eyestuff-eyeblock.png",
        "eyestuff-eyeblock.png",
        "eyestuff-eyeblock.png",
        "eyestuff-eyeblock.png"
    },groups = {cracky = 1, level = 3}
})
print("This block is watching you")
minetest.register_node("eyestuff:circleblock", {
    description = "swirly",
    tiles = {
        "eyestuff-circleblock.png",
        "eyestuff-circleblock.png",
        "eyestuff-circleblock.png",
        "eyestuff-circleblock.png",
        "eyestuff-circleblock.png",
        "eyestuff-circleblock.png"
    },groups = {cracky = 1, level = 3},light_source = 9999})


local pickaxe_desc = ("Swirly pickaxe")
minetest.register_tool("eyestuff:Swirly_pickaxe", {
	description = toolranks_loaded and toolranks.create_description(pickaxe_desc) or pickaxe_desc,
	inventory_image = "Swirlypick.png",
	tool_capabilities = {
		full_punch_interval = 0.1,
		max_drop_level=88, 
		groupcaps={
			cracky = {times={[1]=1.0, [2]=1.0, [3]=0.50}, uses=99, maxlevel=88},
		},
		damage_groups = {fleshy=9999, fire=666},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {pickaxe = 1},
})

